
#ifndef __HTTP_AUTO_REG_CONTROL_HTTPRESTFUL_HPP
#define __HTTP_AUTO_REG_CONTROL_HTTPRESTFUL_HPP

#if defined(_MSC_VER) && (_MSC_VER >= 1200)
#pragma once
#endif // defined(_MSC_VER) && (_MSC_VER >= 1200)

#include "httppeer.h" 



namespace http
{
  void _initauto_control_httprestful_paths(std::map<std::string, std::vector<std::string>>  &restfulmethod)
  {
    

		restfulmethod["user/info"]={{""},{""},{"userid"}};
		restfulmethod["user/profile"]={{""},{""},{"userid"},{"pathid"}};

    }
}

#endif

    