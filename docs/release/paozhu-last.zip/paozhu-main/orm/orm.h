/*build this file time Tue, 20 Dec 2022 11:40:56 GMT*/

#include "cms/include/Article.h"
#include "cms/include/User.h"
#include "cms/include/Testa.h"
#include "cms/include/Testb.h"
#include "cms/include/Department.h"
#include "cms/include/Topic.h"
#include "cms/include/Siteinfo.h"