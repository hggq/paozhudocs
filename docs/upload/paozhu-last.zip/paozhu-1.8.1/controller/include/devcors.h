
#pragma once
#include <chrono>
#include <thread>
#include "httppeer.h"

namespace http
{        
	std::string api_dev_hostcors(std::shared_ptr<httppeer> peer);
}
